module Main where

    double :: Integer -> Integer
    double x = x + x
