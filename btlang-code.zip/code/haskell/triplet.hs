module Main where
    data Triplet a = Trio a a a deriving (Show)
