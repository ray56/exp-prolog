object TrueRing {
 def rule = println("To rule them all")
}
TrueRing.rule
